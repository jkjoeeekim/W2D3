# Tic-Tac-Toe Version 4



## How to run

In your terminal:
    - change directory(cd) into the folder `version_4`
    - execute the command `ruby game_setup.rb`